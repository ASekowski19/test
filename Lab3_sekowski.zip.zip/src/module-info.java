module lab3_Sekowski {
}